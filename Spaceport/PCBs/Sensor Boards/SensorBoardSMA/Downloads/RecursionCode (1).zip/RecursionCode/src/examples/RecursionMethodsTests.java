package examples;

import static org.junit.Assert.*;

import org.junit.Test;

public class RecursionMethodsTests {

	@Test
	public void testPrint() {
		StringRecursiveMethods.printString("a");
		System.out.println();
		StringRecursiveMethods.printString2("aba");
		System.out.println();
		StringRecursiveMethods.printString2("ABCD");
		/* No assertion */
	}
	
	@Test
	public void testFind() {
		assertTrue(StringRecursiveMethods.find("abaFc", 'F'));
	}
	
	@Test
	public void testFind2() {
		assertFalse(StringRecursiveMethods.find("abaFc", 'G'));
	}
	
	@Test
	public void testCount() {
		assertEquals(StringRecursiveMethods.countChar("abaaac", 'a'), 4);
	}
	
	@Test
	public void testRemoveChar() {
		assertTrue(StringRecursiveMethods.removeChar("abaaac",'a').equals("bc"));
	}
	
	@Test
	public void testReverse() {
		assertTrue(StringRecursiveMethods.reverse("abc").equals("cba"));
		assertTrue(StringRecursiveMethods.reverse2("abc").equals("cba"));
	}
}