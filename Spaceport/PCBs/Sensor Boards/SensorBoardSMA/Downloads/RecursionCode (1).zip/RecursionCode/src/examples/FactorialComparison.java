package examples;

import java.util.Scanner;

public class FactorialComparison {

	public static long factRecursive(long n) {
		if (n == 0) {
			return 1;
		} else {
			return n * factRecursive(n - 1);
		}
	}

	public static long factIterative(long n) {
		long i, answer = 1;

		for (i = n; i > 0; i--) {
			answer = answer * i;
		}

		return answer;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter true for iterative and false otherwise: ");
		boolean iterative = scanner.nextBoolean();
		scanner.close();

		long max = 50;
		for (int i = 0; i <= max; i++) {
			System.out.println(i + " ---> " + (iterative ? factIterative(i) : factRecursive(i)));
		}
		long value = 45000;
		System.out.print(value + " ---> ");
		System.out.println(iterative ? factIterative(value) : factRecursive(value));
	}
}